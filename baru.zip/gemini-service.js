// Gemini AI Service for enhanced features
class GeminiService {
    constructor(apiKey) {
        this.apiKey = apiKey;
        this.baseURL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent';
    }

    async generateContent(prompt) {
        if (!this.apiKey || this.apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
            console.warn('Gemini API key not configured');
            return this.getFallbackResponse(prompt);
        }

        try {
            const response = await fetch(`${this.baseURL}?key=${this.apiKey}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    contents: [{
                        parts: [{
                            text: prompt
                        }]
                    }]
                })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            return data.candidates[0].content.parts[0].text;
        } catch (error) {
            console.error('Error calling Gemini API:', error);
            return this.getFallbackResponse(prompt);
        }
    }

    getFallbackResponse(prompt) {
        // Fallback responses when API is not available
        const fallbackBios = [
            "Tech enthusiast and music lover 🎵 | Building cool stuff with code 💻 | Always learning, always growing 🌱",
            "Digital creator passionate about technology and creativity 🚀 | Love connecting with amazing people worldwide 🌍",
            "Turning ideas into reality through code and creativity ✨ | Music, tech, and good vibes only 🎶",
            "Full-stack dreamer and digital innovator 💫 | Creating meaningful connections through technology 🤝",
            "Code by day, music by night 🎧 | Building the future one line at a time 🔮"
        ];

        const fallbackRecommendations = [
            { name: "GitHub Portfolio", url: "https://github.com", icon: "fa-brands fa-github", badge: "Code" },
            { name: "LinkedIn Profile", url: "https://linkedin.com", icon: "fa-brands fa-linkedin", badge: "Professional" },
            { name: "YouTube Channel", url: "https://youtube.com", icon: "fa-brands fa-youtube", badge: "Video" },
            { name: "Personal Blog", url: "https://medium.com", icon: "fa-brands fa-medium", badge: "Writing" }
        ];

        if (prompt.includes('bio')) {
            return fallbackBios[Math.floor(Math.random() * fallbackBios.length)];
        } else if (prompt.includes('recommend')) {
            return JSON.stringify(fallbackRecommendations);
        } else {
            return "I'm here to help! As an AI assistant, I can answer questions and provide information. How can I assist you today?";
        }
    }

    async generatePersonalizedBio(name, interests) {
        const prompt = `Create a short, engaging personal bio for ${name} who is interested in ${interests.join(', ')}. The bio should be maximum 2 sentences, catchy, and include relevant emojis. Make it personal and authentic.`;
        return await this.generateContent(prompt);
    }

    async generateLinkRecommendations(profileInfo) {
        const prompt = `Based on a person named ${profileInfo.name} with interests in ${profileInfo.interests.join(', ')}, suggest 3-4 relevant website links they might want to share. Return only a JSON array of objects with format: [{"name": "Link Name", "url": "https://example.com", "icon": "font-awesome-class", "badge": "Category"}]`;
        const response = await this.generateContent(prompt);
        
        try {
            // Extract JSON from response if it's wrapped in text
            const jsonMatch = response.match(/\[.*\]/s);
            return jsonMatch ? JSON.parse(jsonMatch[0]) : JSON.parse(response);
        } catch (e) {
            console.error('Error parsing AI recommendations:', e);
            return this.getFallbackResponse('recommendations');
        }
    }

    async chatWithAI(message, conversationHistory = []) {
        const prompt = `You are a friendly AI assistant for a personal Linktree page. The user is visiting Arfi's profile. Keep responses concise, helpful, and friendly. Previous conversation: ${conversationHistory.join('\n')}. Current message: ${message}`;
        return await this.generateContent(prompt);
    }
}

// Initialize Gemini Service
const geminiService = new GeminiService(CONFIG.GEMINI_API_KEY);